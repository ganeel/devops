python_test Cookbook
====================

This cookbook tests the pip and virtualenv providers

Requirements
------------

#### packages
- `python` - Version *2.5* or higher

License and Authors
-------------------
Authors: Scott Likens <scott@mopub.com>
		 Sean Porter <portertech@gmail.com>
