# frozen_string_literal: true
name 'test'
maintainer 'Sous Chefs'
maintainer_email 'help@sous-chefs.org'
license 'Apache 2.0'
description 'Installs/Configures test'
version '0.1.0'
depends 'postgresql'
