#
# Cookbook Name:: postgresql
# Attributes:: postgis
#
# Author:: Phil Cohen <github@phlippers.net>
#
# Copyright 2012-2013, Phil Cohen
#

default["postgis"]["version"] = "2.1"
