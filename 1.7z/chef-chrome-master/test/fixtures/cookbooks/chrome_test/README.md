This is a test cookbook for use by chefspec and test-kitchen
