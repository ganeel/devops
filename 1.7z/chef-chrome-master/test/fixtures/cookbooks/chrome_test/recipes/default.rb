include_recipe 'chrome'
include_recipe 'chrome_test::version'
include_recipe 'chrome_test::master_preferences'
