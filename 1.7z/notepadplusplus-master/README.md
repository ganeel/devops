Description
===========

This cookbook installs Notepad++ 6.2.2

Requirements
============

Platform
--------

* Windows Vista
* Windows 7
* Windows Server 2008 (R1, R2)
* Windows 2003 (R1 / R2)
* Windows XP


Attributes
==========

Usage
=====

Include the default recipe on a node's runlist to ensure that Notepad++ is installed