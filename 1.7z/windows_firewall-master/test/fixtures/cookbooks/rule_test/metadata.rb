name 'rule_test'
version '0.0.1'

depends 'windows_firewall'
