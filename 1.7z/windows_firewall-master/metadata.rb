name             'windows_firewall'
maintainer       'Matt Clifton'
maintainer_email 'spartacus003@hotmail.com'
license          'Apache 2.0'
description      'Configures firewall rules on Windows'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
#source_url       'https://github.com/lynx44/windows_firewall'
supports         'windows'
version          '3.0.2'
