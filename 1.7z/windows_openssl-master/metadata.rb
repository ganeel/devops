name 'windows_openssl'
maintainer 'Chris Allen'
maintainer_email 'csallen1204@gmail.com'
license 'all_rights'
description 'Compiles and Installs OpenSSL for Windows'
long_description 'Compiles and Installs OpenSSL for Windows'
version '0.1.0'
depends 'mingw'
depends 'msys2'

# If you upload to Supermarket you should set this so your cookbook
# gets a `View Issues` link
# issues_url 'https://github.com/<insert_org_here>/windows_openssl/issues' if respond_to?(:issues_url)

# If you upload to Supermarket you should set this so your cookbook
# gets a `View Source` link
# source_url 'https://github.com/<insert_org_here>/windows_openssl' if respond_to?(:source_url)
