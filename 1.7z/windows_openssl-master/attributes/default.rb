default['openssl']['version'] = '1.0.2h'
#Pick "1.1.0, 1.0.1t or 1.0.2h"
