# windows_openssl

This cookbook is to download, compile and install OpenSSL for Windows
