name 'mysql_test'
version '0.0.1'

depends 'mysql'
depends 'yum-mysql-community'
